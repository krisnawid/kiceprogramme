<?php $__env->startSection('content'); ?>
	<tr>
	<td class="bg_white email-section" style="text-align:center; background-color: white">
		<div class="heading-section heading-section-dark">
		  <h2>Pendaftaran</h2>
		  <p style="color: black">Hai <?php echo e($data['namaDepan']); ?> <?php echo e($data['namaBelakang']); ?>, saat ini tim kami sedang memproses pendaftaran kamu, tim kami akan menghubungi kamu kembali saat terjadi perubahan status pendaftaran.</p>
		</div>
	</td>
  </tr><!-- end: tr -->
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('email.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\KRISNA\PHP\BACKUP\clone-branch\pertukaran-pelajar\resources\views/email/emailregistration.blade.php ENDPATH**/ ?>