<?php $__env->startSection('content'); ?>
    <!-- Container Fluid-->
    <div class="container-fluid" id="container-wrapper">
      <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Data Registration User</h1>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="./">Home</a></li>
          <li class="breadcrumb-item">Tables</li>
          <li class="breadcrumb-item active" aria-current="page">Data Registration User</li>
        </ol>
      </div>

      <div class="row">
        <div class="col-lg-12 mb-4">
          <!-- Data Registration User -->
          <div class="card">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
              <h6 class="m-0 font-weight-bold text-primary">Data Registration User</h6>
            </div>
            <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th>Registration ID</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><a href="#"><?php echo e($user->id); ?></a></td>
                    <td><?php echo e($user->nama_depan); ?> <?php echo e($user->nama_belakang); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    
                    <?php if($user->status == 0 && $user->status == null): ?>
                      <td><span class="badge badge-primary">Pending</span></td>    
                    <?php elseif($user->status == 1): ?>
                      <td><span class="badge badge-success">Terkonfirmasi</span></td>
                    <?php else: ?>
                      <td><span class="badge badge-danger">Reject</span></td>
                    <?php endif; ?>
                    <td><a href="/admin/<?php echo e($user->id); ?>/detaildatauser" class="btn btn-sm btn-primary">Detail</a></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <div class="card-footer"></div>
          </div>
        </div>
      </div>
      <!--Row-->
    </div>
    <!---Container Fluid-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\KRISNA\PHP\BACKUP\clone-branch\pertukaran-pelajar\resources\views/admin/data-tables/index.blade.php ENDPATH**/ ?>