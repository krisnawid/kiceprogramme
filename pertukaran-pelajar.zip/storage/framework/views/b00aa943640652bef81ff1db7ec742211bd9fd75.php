<?php $__env->startSection('content'); ?>
    <!-- Container Fluid-->
    <div class="container-fluid" id="container-wrapper">
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">Data Peserta</h1>
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="./">Home</a></li>
                <li class="breadcrumb-item">Tables</li>
                <li class="breadcrumb-item active" aria-current="page">Biodata Dan Hasil Pembayaran</li>
              </ol>
            </div>
  
            <div class="row">
              <div class="col-lg-12 mb-4">
                <!-- Simple Tables -->
                <div class="card">
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Biodata Peserta dan Bukti Pembayaran</h6>
                  </div>
                  <div class="table-responsive">
                    <table class="table align-items-center table-flush">
                      <thead class="thead-light">
                          <div class="container">
                              <form action="/admin/<?php echo e($user->id); ?>/confirmdatauser" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                  <div class="form-group row">
                                      <label class="col-sm-2 col-form-label">Registration ID : </label>
                                      <div class="col-sm-10 ">
                                          <input type="text" readonly class="form-control-plaintext" name="id_user" value="<?php echo e($user->id); ?>" disabled>
                                      </div>
                                  </div>
                                  <div class="form-group row">
                                      <label class="col-sm-2 col-form-label">Nama Depan :</label>
                                      <div class="col-sm-10">
                                          <input type="text" class="form-control" name="nama_depan" value="<?php echo e($user->nama_depan); ?>" disabled>
                                      </div>
                                  </div>
                                  <div class="form-group row">
                                      <label class="col-sm-2 col-form-label">Nama Nelakang : </label>
                                      <div class="col-sm-10">
                                          <input type="text" class="form-control" name="nama_belakang" value="<?php echo e($user->nama_belakang); ?>" disabled>
                                      </div>
                                  </div>
                                  <div class="form-group row">
                                      <label class="col-sm-2 col-form-label">Email : </label>
                                      <div class="col-sm-10">
                                          <input type="text" class="form-control" name="email" value="<?php echo e($user->email); ?>" disabled>
                                      </div>
                                  </div>
                                  <div class="form-group row">
                                      <label class="col-sm-2 col-form-label">Phone : </label>
                                      <div class="col-sm-10">
                                          <input type="text" class="form-control" name="phone" value="<?php echo e($user->phone); ?>" disabled>
                                      </div>
                                  </div>
                                  <div class="form-group row">
                                      <label class="col-sm-2 col-form-label">Alamat : </label>
                                      <div class="col-sm-10">
                                          <input type="text" class="form-control" name="alamat" value="<?php echo e($user->alamat); ?>" disabled>
                                      </div>
                                  </div>
                                  <div class="form-group row">
                                      <label class="col-sm-2 col-form-label">Bukti Pembayaran : </label>
                                      <div class="col-sm-10">
                                          <label><img src="<?php echo e(url('/data_file/'.$user->bukti_pembayaran)); ?>" name="bukti_pembayaran" style="width: 400px; height: 400px;" alt=""></label>
                                      </div>
                                  </div>
                                  <div class="form-group row">
                                      <label class="col-sm-2 col-form-label">Foto Peserta : </label>
                                      <div class="col-sm-10">
                                          <label><img src="<?php echo e(url('/data_file/'.$user->foto_peserta)); ?>" name="foto_peserta" style="width: 400px; height: 400px;" alt=""></label>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group row">
                                      
                                      <div class="col-sm-10">
                                          <input type="hidden" class="form-control" name="status" value="1">
                                      </div>
                                  </div>
                                  <?php if($user->status == 1): ?>
                                    <div class="alert alert-light text-center"><span class="badge badge-success">Data Sudah Terkonfirmasi</span></div>
                                    <a class="btn btn-danger btn-block" href="/admin/data-tables" >Back</a>
                                  <?php else: ?>
                                    <div class="alert alert-light text-center"><span class="badge badge-primary">Data Belum Terkonfirmasi</span></div>
                                    <button type="submit" data-toggle="modal" data-target="#modalKonfrimasi" class="btn btn-success btn-lg btn-block">Konfirmasi Data Registrasi</button>
                                    <a class="btn btn-danger btn-lg btn-block" href="/admin/data-tables" >Back</a>
                                  <?php endif; ?>
                              </form>
                          </div>                        
                      </thead>
                    </table>
                  </div>
                  <div class="card-footer"></div>
                </div>
              </div>
            </div>
            <!--Row-->
          </div>
          <!---Container Fluid-->

          <div class="modal fade" id="modalKonfrimasi" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Konfirmasi Diproses</h5>
                    </div>
                    <div class="modal-body">
                        Tunggu sebentar konfirmasi sedang diproses
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\KRISNA\PHP\BACKUP\clone-branch\pertukaran-pelajar\resources\views/admin/data-tables/detailpeserta.blade.php ENDPATH**/ ?>