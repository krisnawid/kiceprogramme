@extends('admin.layout.master')

@section('content')
    <!-- Container Fluid-->
    <div class="container-fluid" id="container-wrapper">

        <!-- Area Chart -->
        <div class="col-lg-12" style="padding: 50px">
          <div class="card mb-4" style="padding: 50px">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            </div>
            <div class="card-body">
              <h1 class="text-center">Welcome Admin</h1>
            </div>
          </div>
        </div>

    </div>
    <!---Container Fluid-->
@endsection